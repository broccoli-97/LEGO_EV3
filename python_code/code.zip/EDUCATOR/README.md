# EDUCATOR
These demonstration scripts are for the EDUCATOR robot that can be built using
the Education kit (45544). You can also build a close approximation using the
Home kit (31313) if you purchase some additional parts such as a gyro sensor and
ultrasonic sensor. You can substitute the ball and socket from the Education
kit with a single rear wheel.

**Building Instructions Using Education Kit (45544)**: https://education.lego.com/en-au/support/mindstorms-ev3/building-instructions

**Building Instructions Using Home Kit (31313)**:
https://sites.google.com/site/gask3t/lego-ev3/building-plans/educator-vehicle-retail-kit-version
