R3PTAR
======

One of the most loved robots, the standing 35 cm. / 13,8 inch tall R3PTAR robot
slithers across the floor like a real cobra, and strikes at lightning speed
with it’s pointed red fangs.

Coincidentally, its also a nice example to demonstrate how to use threads in
Python.

**Building instructions**: http://www.lego.com/en-us/mindstorms/build-a-robot/r3ptar

**Resources**:

* `rattle-snake.wav`: https://www.freesound.org/people/7h3_lark/sounds/268580/
* `snake-hiss.wav`: https://www.freesound.org/people/Reitanna/sounds/343928/
