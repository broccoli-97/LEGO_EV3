EV3RSTORM
=========

EV3RSTORM is the most advanced of the LEGO(r) MINDSTORMS(r) Robots.
Equipped with a blasting bazooka and a spinning tri-blade, EV3RSTORM is
superior in both intelligence as well as in fighting power.

Our version, being built with ev3dev, is also vastly more intelligent (one
could say, it has a [brain size of a planet](https://en.wikipedia.org/wiki/Marvin_(character)))
so it may be afflicted with severe depression and boredom at times.

The build instructions may be found at the official LEGO MINDSTROMS site
[here](http://www.lego.com/en-us/mindstorms/build-a-robot/ev3rstorm).

