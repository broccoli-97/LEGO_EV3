# BALANC3R
This demonstration script is for the BALANC3R robot.

**Building Instructions**: http://robotsquare.com/2014/07/01/tutorial-ev3-self-balancing-robot/

**Note**: You will also need to add a touch sensor to port 1. Add it just
like the Gyro, but on the other side of the brick. It will act as the program's
safe stop button.
