The examples in this folder, unless stated otherwise, are based on Explor3r
robot by Laurens Valk. The assembling instructions for the robot may be found
here: http://robotsquare.com/2015/10/06/explor3r-building-instructions.
